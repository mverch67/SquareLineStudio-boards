// This directory contains the exported LVGL library. It is automatically exported into this folder by Squareline Studio when invoking the export function.
